
void put_char(char c);

int get_char();

void read(int fd,char* buffer,int size);

void write(int fd,char* msg,int size);

void print_string(char* arr);

void new_line();

void get_ticks();

void call_beep();

void clear_screen();
