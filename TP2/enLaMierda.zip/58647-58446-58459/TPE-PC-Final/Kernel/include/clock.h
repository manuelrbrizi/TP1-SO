void time();

void date();