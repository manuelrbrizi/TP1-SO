void get_time();
void get_date();