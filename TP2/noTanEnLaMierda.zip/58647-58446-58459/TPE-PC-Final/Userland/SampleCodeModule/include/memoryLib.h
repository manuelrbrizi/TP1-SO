
void * malloc(int size);
void free(void *ptr,int size);

