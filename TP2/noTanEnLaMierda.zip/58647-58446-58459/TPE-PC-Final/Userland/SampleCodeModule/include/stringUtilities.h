#ifndef STRINGS_H
#define STRINGS_H

int strlen(const char* str);

void toUpper(char* str);

int strcmp(const char* str1,const char* str2);

int uintToBase(int value, char * buffer, int base);

#endif
