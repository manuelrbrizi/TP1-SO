void drawPixel(int x, int y, int colour);

void drawChar(char c, int colour);

void drawString(const char* str, int size);

void scroll();

void newLine();

void clear();

void drawBall(int x, int y);

void drawBar(int x, int y);

void erase_char();



