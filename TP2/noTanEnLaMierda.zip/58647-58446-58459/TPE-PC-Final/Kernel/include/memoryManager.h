// void * malloc(int size, void ** ptr);
void * malloc(int size);


void free(void * ptr,int size);