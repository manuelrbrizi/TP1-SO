void draw_pixel(int x, int y);

void printBall(int x, int y);

void printBar(int distance, int length, int x);

void clear_screen();
