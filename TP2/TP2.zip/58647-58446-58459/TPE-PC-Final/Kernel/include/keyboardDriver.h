void clear_buffer();

void update_buffer();

void read_buffer();