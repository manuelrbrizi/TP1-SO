#ifndef _idtLoader_
#define _idtLoader_

void load_idt();

#endif /* _idtLoader? */